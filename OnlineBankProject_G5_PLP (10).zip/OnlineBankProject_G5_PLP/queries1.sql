select * from user_table;

create table User_Table
(
user_id VARCHAR2(20) primary key,
Account_ID NUMBER,
login_password VARCHAR2(15),
secret_question VARCHAR2(50),
secret_answer VARCHAR2(50),
Transaction_password VARCHAR2(15),
lock_status VARCHAR2(10),foreign key(Account_ID) references Account_Master(Account_ID) 
);

insert into USER_TABLE VALUES(12345,1234,'abcd','sd','tc','789','L');


insert into USER_TABLE VALUES(12345,1789542,'abcd','sd','bd','789','L');
select * from USER_TABLE;

select * from TRANSACTION;

delete REQUESTTABLE;
select * from REQUESTTABLE;

select * from REQUESTTABLE;

drop table REQUESTTABLE;
delete from RequestTable where customer_ID=1500201;


create table Customer(
Customer_ID NUMBER(10) primary key,
customer_name VARCHAR2(50),
Email VARCHAR2(30),
Mobile_No NUMBER(10),
Address VARCHAR2(100),
Pancard VARCHAR2(15));

select * from CUSTOMER;
delete customer where customer_id=1500243;


drop sequence custid_seq;
create sequence custid_seq start with 1500200 increment by 1 nocache;
delete customer where customer_id=1002;

insert into customer values(custid_seq.nextVal,'Subbu','subbu@gmail.com',9564123625,'Kalyan','P1450213');
insert into customer values(custid_seq.nextVal,'Shalu','shalu@yahoo.com',7896541230,'Dadar','P1425963');
insert into customer values(custid_seq.nextVal,'Sandeep','sandeeo@rediff.com',9638527410,'Malad','P1499513');
insert into customer values(custid_seq.nextVal,'Akhil','akhil@rediff.com',9638125310,'Matunga','P1488513');
select custid_seq.nextVal from dual;


create table Account_Master
(Account_ID NUMBER(10) primary key,
Customer_ID number(10),
Account_Type VARCHAR2(25),
Account_Balance NUMBER(10,2),
Open_Date DATE,
FOREIGN KEY(Customer_ID) REFERENCES customer(Customer_ID));

create sequence accid_seq start with 12001200 increment by 1 nocache;

insert into account_master values(accid_seq.nextVal,1500202,'Saving',15000,'03-apr-2017');

select * from ACCOUNT_MASTER;

delete REQUESTTABLE where customer_id=1500243;


drop table requesttable;

create table RequestTable
(
customer_ID number(10) primary key,
AccountType varchar2(15),
AccountId number(10)
);

insert into REQUESTTABLE values (1500200,'Saving',accid_seq.nextVal);

select * from REQUESTTABLE;

drop table transactions;
create table Transaction
(
Transaction_ID NUMBER primary key ,
Tran_description VARCHAR2(100),
DateofTransaction DATE ,
TransactionType VARCHAR2(1),TranAmount NUMBER(15) ,
Account_ID NUMBER(10),
FOREIGN KEY(Account_ID) REFERENCES Account_Master(Account_ID)
);


create sequence tranID_seq start with 100200 increment by 1 nocache;


insert into TRANSACTION values(tranID_seq.nextVal,'pos','02-oct-2011','k',500,1000001);

insert into TRANSACTION values(tranID_seq.nextVal,'rent','02-oct-2011','k',400,1000001);

insert into TRANSACTION values(tranID_seq.nextVal,'pos','01-oct-2013','k',400,1000001);

insert into TRANSACTION values(tranID_seq.nextVal,'Shopping','07-oct-2013','k',400,12001201);

insert into TRANSACTION values(tranID_seq.nextVal,'rent','30-oct-2013','k',400,12001201);

insert into TRANSACTION values(tranID_seq.nextVal,'pos','01-jan-2012','k',500,12001201);


insert into TRANSACTION values(tranID_seq.nextVal,'Recharge','25-jun-2012','k',700,12001201);



select * from transaction;

select * from customer;

create sequence seq_service_num start with 100010 increment by 1 nocache;




create table Service_Tracker(
Service_ID NUMBER(15) primary key, 
Service_Description VARCHAR2(100),
Account_ID NUMBER, 
Service_Raised_Date DATE ,
Service_status VARCHAR2(20),
foreign key(Account_ID) references Account_Master(Account_ID) 
);




